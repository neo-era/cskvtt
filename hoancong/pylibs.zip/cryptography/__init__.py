# stub: trinh duyet khong co cryptography; chi can cho PDF ma hoa (bien ban khong ma hoa)
