class _NA:
    def __getattr__(self,k): raise RuntimeError('PDF ma hoa: khong ho tro trong trinh duyet')
    def __call__(self,*a,**k): raise RuntimeError('PDF ma hoa: khong ho tro trong trinh duyet')
Cipher=_NA(); algorithms=_NA(); modes=_NA()
